# xlReg/__init__.py

__version__      = '0.1.14'
__version_date__ = '2016-02-22'

__all__ = ['__version__',   '__version_date__', 
           'AES_BLOCK_SIZE',]

AES_BLOCK_SIZE = 16




