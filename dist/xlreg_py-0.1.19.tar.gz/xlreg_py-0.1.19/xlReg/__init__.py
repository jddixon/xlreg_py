# xlReg/__init__.py

__version__ = '0.1.19'
__version_date__ = '2016-08-29'

__all__ = ['__version__', '__version_date__',
           'AES_BLOCK_SIZE', ]

AES_BLOCK_SIZE = 16
