# xlReg/__init__.py

__version__      = '0.1.11'
__version_date__ = '2015-12-04'

__all__ = ['AES_BLOCK_SIZE',]

AES_BLOCK_SIZE = 16

