# xlReg/__init__.py

__version__      = '0.1.6'
__version_date__ = '2015-04-16'

__all__ = ['AES_BLOCK_SIZE',]

AES_BLOCK_SIZE = 16
