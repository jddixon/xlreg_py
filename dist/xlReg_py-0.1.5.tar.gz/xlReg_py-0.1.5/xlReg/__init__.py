# xlReg/__init__.py

__version__      = '0.1.5'
__version_date__ = '2015-04-15'

__all__ = ['AES_BLOCK_SIZE',]

AES_BLOCK_SIZE = 16
