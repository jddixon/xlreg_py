# xlReg/__init__.py

__version__      = '0.1.13'
__version_date__ = '2015-12-22'

__all__ = ['__version__',   '__version_date__', 
           'AES_BLOCK_SIZE',]

AES_BLOCK_SIZE = 16



