# xlReg/__init__.py

__version__      = '0.1.4'
__version_date__ = '2015-04-15'

# __all__ = ['helloAndGoodbye',]
