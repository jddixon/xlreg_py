# xlReg/__init__.py

__version__      = '0.1.2'
__version_date__ = '2014-12-14'

__all__ = ['DecimalVersion',]
