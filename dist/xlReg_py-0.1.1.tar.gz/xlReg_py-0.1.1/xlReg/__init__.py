# xlReg/__init__.py

__version__      = '0.1.1'
__version_date__ = '2014-12-07'

__all__ = ['DecimalVersion',]
