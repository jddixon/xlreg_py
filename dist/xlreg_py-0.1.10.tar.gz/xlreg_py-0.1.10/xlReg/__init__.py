# xlReg/__init__.py

__version__      = '0.1.10'
__version_date__ = '2015-10-14'

__all__ = ['AES_BLOCK_SIZE',]

AES_BLOCK_SIZE = 16
